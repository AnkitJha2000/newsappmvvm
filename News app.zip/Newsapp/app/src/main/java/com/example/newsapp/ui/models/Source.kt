package com.example.newsapp.ui.models

data class Source(
    val id: Any,
    val name: String
)