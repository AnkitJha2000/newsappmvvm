package com.example.newsapp.ui.ui.fragments

import android.app.Fragment
import android.os.Bundle
import android.view.View
import androidx.lifecycle.ViewModel
import androidx.navigation.fragment.navArgs
import com.example.newsapp.R
import com.example.newsapp.ui.models.Article
import com.example.newsapp.ui.ui.MainActivity

class ArticleFragment : androidx.fragment.app.Fragment(R.layout.fragment_article) {

    lateinit var viewModel: ViewModel
    val args: ArticleFragmentArgs by navArgs<Article>()
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)
        viewModel = (activity as MainActivity).viewModel

    }
}