
package com.example.newsapp.ui.util

class Constants {

    companion object{
        const val API_KEY = "20b03be6136a411fa7b33343dbb40ab1"
        const val BASE_URL = "https://newsapi.org"
    }

}